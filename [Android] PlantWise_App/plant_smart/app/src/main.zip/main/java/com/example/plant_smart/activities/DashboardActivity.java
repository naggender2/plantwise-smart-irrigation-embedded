package com.example.plant_smart.activities;
import com.example.plant_smart.models.SensorData;
import com.example.plant_smart.helpers.MockDataGenerator;
import android.content.Context;
import android.widget.Toast;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.navigation.NavigationView;
import com.example.plant_smart.R;


public class DashboardActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private TextView textHumidity, textMoisture, textBrightness;
    private EditText editThreshold;
    private Switch switchMode;
    private Button btnPump;
    private Handler handler = new Handler();
    private DrawerLayout drawer;
    private NavigationView navigationView;
    private static final int REFRESH_INTERVAL_MS = 10000; // 10 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Set up toolbar and navigation drawer
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        // Find UI elements
        textHumidity = findViewById(R.id.textHumidity);
        textMoisture = findViewById(R.id.textMoisture);
        textBrightness = findViewById(R.id.textBrightness);
        editThreshold = findViewById(R.id.editThreshold);
        switchMode = findViewById(R.id.switchMode);
        btnPump = findViewById(R.id.btnPump);

        // Load saved threshold
        SharedPreferences prefs = getSharedPreferences("PlantSmartPrefs", Context.MODE_PRIVATE);
        int savedThreshold = prefs.getInt("wateringThreshold", 50);
        editThreshold.setText(String.valueOf(savedThreshold));

        // Initially hide pump button
        btnPump.setVisibility(View.GONE);

        // Toggle pump button based on mode
        switchMode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton button, boolean isChecked) {
                if (isChecked) {
                    // Manual mode: show pump button
                    btnPump.setVisibility(View.VISIBLE);
                } else {
                    // Auto mode: hide pump button
                    btnPump.setVisibility(View.GONE);
                }
            }
        });

        btnPump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DashboardActivity.this, "Pump toggled!", Toast.LENGTH_SHORT).show();
            }
        });

        // Start updating sensor values periodically
        handler.post(updateTask);
    }

    // Periodic task to update sensor values
    private Runnable updateTask = new Runnable() {
        @Override
        public void run() {
            // Fetch dummy sensor data (could be from MQTT in real app)
            SensorData data = MockDataGenerator.generateSensorData();
            textHumidity.setText("Humidity: " + data.getHumidity() + "%");
            textMoisture.setText("Soil Moisture: " + data.getSoilMoisture() + "%");
            textBrightness.setText("Brightness: " + data.getBrightness() + "%");
            handler.postDelayed(this, REFRESH_INTERVAL_MS);
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateTask);
    }

    // Handle navigation menu item clicks
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        drawer.closeDrawer(GravityCompat.START);
        int id = item.getItemId();
        if (id == R.id.nav_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
        } else if (id == R.id.nav_plant_profile) {
            startActivity(new Intent(this, PlantProfileActivity.class));
        } else if (id == R.id.nav_history) {
            startActivity(new Intent(this, HistoryActivity.class));
        } else if (id == R.id.nav_logout) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
