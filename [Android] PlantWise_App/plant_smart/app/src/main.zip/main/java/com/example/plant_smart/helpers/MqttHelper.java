package com.example.plant_smart.helpers;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import info.mqtt.android.service.Ack;
import info.mqtt.android.service.MqttAndroidClient;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttMessageListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;

public class MqttHelper {
    private static final String TAG = "MqttHelper";
    private static final String SERVER_URI = "tcp://192.168.106.42";  // Ensure proper URI format

    private final MqttAndroidClient client;
    private final Handler pingHandler;
    private final Runnable pingRunnable;

    public MqttHelper(Context ctx) {
        String clientId = MqttClient.generateClientId();
        this.client = new MqttAndroidClient(
                ctx.getApplicationContext(),
                SERVER_URI,
                clientId,
                Ack.AUTO_ACK
        );

        // Disable automatic reconnect and pinging system
        MqttConnectOptions options = new MqttConnectOptions();
        options.setAutomaticReconnect(false);  // Disable automatic reconnect
        options.setCleanSession(true);  // Optional, ensures clean session without persistence

        this.pingHandler = new Handler(Looper.getMainLooper());

        this.pingRunnable = new Runnable() {
            @Override
            public void run() {
                if (client.isConnected()) {
                    try {
                        client.publish("plant/ping", "ping".getBytes(), 0, false);
                        Log.d(TAG, "Sent custom ping");
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to send ping", e);
                    }
                } else {
                    Log.w(TAG, "Client not connected, skipping ping");
                }
                pingHandler.postDelayed(this, 60000);  // Ping every 60 seconds
            }
        };
    }

    public void connectAndSubscribe(String topic) {
        MqttConnectOptions options = new MqttConnectOptions();
        options.setAutomaticReconnect(false);  // Disable automatic reconnect
        options.setCleanSession(true);

        client.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.d(TAG, "Connection complete (reconnect=" + reconnect + ")");
                // Immediately subscribe after connection is established
                subscribeToTopic(topic);
                startCustomPinging();  // Start the custom ping after successful connection
            }

            @Override
            public void connectionLost(Throwable cause) {
                Log.w(TAG, "Connection lost", cause);
            }

            @Override
            public void messageArrived(String topic, org.eclipse.paho.client.mqttv3.MqttMessage message) {
                String sensorData = new String(message.getPayload());
                Log.d(TAG, "Sensor Data Received: " + sensorData);
            }

            @Override
            public void deliveryComplete(org.eclipse.paho.client.mqttv3.IMqttDeliveryToken token) {
                Log.d(TAG, "Delivery complete for token: " + token.getMessageId());
            }
        });

        // Connect with the options set above
        client.connect(options, null, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Log.d(TAG, "Successfully connected to broker");
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Log.e(TAG, "Failed to connect to broker", exception);
            }
        });
    }

    private void subscribeToTopic(String topic) {
        if (!client.isConnected()) {
            Log.w(TAG, "Cannot subscribe: not connected");
            return;
        }

        client.subscribe(topic, 1, null, new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken t) {
                Log.d(TAG, "Successfully subscribed to topic: " + topic);
            }

            @Override
            public void onFailure(IMqttToken t, Throwable e) {
                Log.e(TAG, "Failed to subscribe to topic: " + topic, e);
            }
        });
    }

    public void startCustomPinging() {
        pingHandler.post(pingRunnable);  // Start the custom pinging process
    }

    public void stopCustomPinging() {
        pingHandler.removeCallbacks(pingRunnable);  // Stop the custom pinging process
    }

    public void disconnect() {
        try {
            stopCustomPinging();
            client.disconnect();
            Log.d(TAG, "Disconnected from broker");
        } catch (Exception e) {
            Log.e(TAG, "Failed to disconnect", e);
        }
    }

    public MqttAndroidClient getClient() {
        return client;
    }
}
