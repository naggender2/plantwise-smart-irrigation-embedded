package com.example.plant_smart.activities;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import com.example.plant_smart.R;


public class ProfileActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private TextView textUsername, textCategory, textEnvironment;
    private DrawerLayout drawer;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        // Assuming toggle setup same as Dashboard (omitted for brevity)...

        textUsername = findViewById(R.id.textUsername);
        textCategory = findViewById(R.id.textCategory);
        textEnvironment = findViewById(R.id.textEnvironment);

        SharedPreferences prefs = getSharedPreferences("PlantSmartPrefs", Context.MODE_PRIVATE);
        String username = prefs.getString("username", "");
        String category = prefs.getString("plantCategory", "Not set");
        String environment = prefs.getString("plantEnvironment", "Not set");

        textUsername.setText("Username: " + username);
        textCategory.setText("Plant Category: " + category);
        textEnvironment.setText("Environment: " + environment);
    }

    @Override
    public boolean onNavigationItemSelected(android.view.MenuItem item) {
        // Similar navigation handling as in DashboardActivity
        drawer.closeDrawer(GravityCompat.START);
        int id = item.getItemId();
        if (id == R.id.nav_dashboard) {
            startActivity(new Intent(this, DashboardActivity.class));
        } else if (id == R.id.nav_plant_profile) {
            startActivity(new Intent(this, PlantProfileActivity.class));
        } else if (id == R.id.nav_history) {
            startActivity(new Intent(this, HistoryActivity.class));
        } else if (id == R.id.nav_logout) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
        return true;
    }
}
