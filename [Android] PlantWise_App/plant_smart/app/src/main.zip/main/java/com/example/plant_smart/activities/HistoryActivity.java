package com.example.plant_smart.activities;

import android.os.Bundle;
import android.graphics.Color;
import com.example.plant_smart.models.HistoryData;
import com.example.plant_smart.helpers.MockDataGenerator;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.components.XAxis;
import com.google.android.material.navigation.NavigationView;
import androidx.drawerlayout.widget.DrawerLayout;
import com.example.plant_smart.HistoryAdapter;
import java.util.ArrayList;
import java.util.List;
import com.example.plant_smart.R;


public class HistoryActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private LineChart chart;
    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private DrawerLayout drawer;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Assume toolbar and drawer setup similar to Dashboard (omitted for brevity)

        chart = findViewById(R.id.lineChart);
        recyclerView = findViewById(R.id.recyclerHistory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Generate dummy history data
        List<HistoryData> historyList = MockDataGenerator.generateHistoryData(10);
        adapter = new HistoryAdapter(historyList);
        recyclerView.setAdapter(adapter);

        // Prepare data entries for chart (e.g., using humidity as example)
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < historyList.size(); i++) {
            entries.add(new Entry(i, historyList.get(i).getHumidity()));
        }

        LineDataSet dataSet = new LineDataSet(entries, "Humidity (%)");
        dataSet.setColor(Color.BLUE);
        dataSet.setValueTextColor(Color.BLACK);

        LineData lineData = new LineData(dataSet);
        chart.setData(lineData);
        chart.getDescription().setEnabled(false);
        chart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        chart.invalidate(); // refresh
    }

    @Override
    public boolean onNavigationItemSelected(android.view.MenuItem item) {
        // Navigation handling as before...
        return true;
    }
}
