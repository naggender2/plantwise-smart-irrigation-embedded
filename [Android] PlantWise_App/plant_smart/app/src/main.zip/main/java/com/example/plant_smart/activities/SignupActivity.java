package com.example.plant_smart.activities;

import android.content.Context;
import android.content.Intent; // Needed for Login link
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType; // Needed for password toggle logic if added later
import android.view.View;
import android.widget.Button; // Keep for btnCreateAccount (MaterialButton is a subclass)
import android.widget.EditText;
import android.widget.ImageButton; // Added for Back button
import android.widget.TextView; // Added for Login link
// import android.widget.ImageView; // Only needed if you add manual password toggle logic
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.plant_smart.R;


public class SignupActivity extends AppCompatActivity {

    // --- UI Elements ---
    private EditText editNewUsername, editNewPassword;
    private Button btnCreateAccount; // Keep as Button (MaterialButton is compatible)
    private ImageButton buttonBackSignup; // Added
    private TextView textLoginLink; // Added
    // Optional: private ImageView passwordToggleIcon;
    // -----------------


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Ensure this matches the XML layout file name
        setContentView(R.layout.activity_signup);

        // --- Find Views By ID ---
        // Core elements (IDs kept the same as original XML)
        editNewUsername = findViewById(R.id.editNewUsername);
        editNewPassword = findViewById(R.id.editNewPassword);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        // New elements from the redesigned layout
        buttonBackSignup = findViewById(R.id.buttonBackSignup);
        textLoginLink = findViewById(R.id.textLoginLink);
        // ----------------------


        // --- Set OnClick Listeners ---

        // Listener for the Create Account Button (Existing Logic)
        btnCreateAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newUsername = editNewUsername.getText().toString().trim(); // Use trim()
                String newPassword = editNewPassword.getText().toString().trim(); // Use trim()

                // Basic Validation
                if (newUsername.isEmpty() || newPassword.isEmpty()) {
                    Toast.makeText(SignupActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Save credentials in SharedPreferences
                // Using "PlantSmartPrefs" as the preference file name (consistent with LoginActivity)
                SharedPreferences prefs = getSharedPreferences("PlantSmartPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                // IMPORTANT: Ensure the key "username" matches what LoginActivity uses for validation
                editor.putString("username", newUsername);
                editor.putString("password", newPassword);
                editor.apply(); // Use apply() for asynchronous saving

                Toast.makeText(SignupActivity.this, "Account created. Please log in.", Toast.LENGTH_LONG).show(); // Longer duration might be better
                finish(); // Close SignupActivity and return to LoginActivity
            }
        });

        // Listener for the new Back Button
        buttonBackSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Closes the current activity, returning to the previous one (likely Login)
            }
        });

        // Listener for the new "Login" link TextView
        textLoginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Since we usually finish() SignupActivity after creation,
                // just finishing might be enough. Or explicitly navigate if needed.
                finish();
                // Alternatively, if Signup might be launched from elsewhere:
                // Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                // intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear back stack
                // startActivity(intent);
                // finish();
            }
        });

        // Optional: Add logic for password visibility toggle if you implement manual control
        // ImageView passwordToggleIcon = findViewById(R.id.your_password_toggle_icon_id); // If needed

        // ---------------------------
    }
}