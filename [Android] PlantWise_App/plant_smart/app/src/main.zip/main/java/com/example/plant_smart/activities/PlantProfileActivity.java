package com.example.plant_smart.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.plant_smart.R;


public class PlantProfileActivity extends AppCompatActivity {
    private Spinner spinnerCategory, spinnerEnvironment;
    private SeekBar seekBarThreshold;
    private TextView textThresholdValue;
    private Button btnSaveProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_profile);

        spinnerCategory = findViewById(R.id.spinnerCategory);
        spinnerEnvironment = findViewById(R.id.spinnerEnvironment);
        seekBarThreshold = findViewById(R.id.seekBarThreshold);
        textThresholdValue = findViewById(R.id.textThresholdValue);
        btnSaveProfile = findViewById(R.id.btnSaveProfile);

        // Update threshold text as SeekBar changes
        seekBarThreshold.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textThresholdValue.setText("Threshold: " + progress + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });

        btnSaveProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String category = spinnerCategory.getSelectedItem().toString();
                String environment = spinnerEnvironment.getSelectedItem().toString();
                int threshold = seekBarThreshold.getProgress();

                // Save plant profile settings
                SharedPreferences prefs = getSharedPreferences("PlantSmartPrefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("plantCategory", category);
                editor.putString("plantEnvironment", environment);
                editor.putInt("wateringThreshold", threshold);
                editor.apply();

                Toast.makeText(PlantProfileActivity.this, "Profile saved", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
